#include "StdAfx.h"
#include "tcp.h"
#include <errno.h>

#pragma comment(lib, "ws2_32.lib")


tcp::tcp(void)
{
	m_bInit = false;
	m_isConnect = false;
}

tcp::~tcp(void)
{
	unInit();
}


int tcp::Init()
{
	if ( m_bInit )
		return 1;
	
	// ����socket��̬���ӿ�(dll)  
	WORD wVersionRequested;  
	WSADATA wsaData;    // ��ṹ�����ڽ���Wjndows Socket�Ľṹ��Ϣ��  
	wVersionRequested = MAKEWORD( 2, 2);  
	int err = WSAStartup( wVersionRequested, &wsaData );  
	if ( err != 0 ) {  
		return -1;          //   
	}  

	if ( LOBYTE( wsaData.wVersion ) != 2 || HIBYTE( wsaData.wVersion ) != 2 ) 
	{  
		// 
		WSACleanup( );  
		return -1;   
	}  

	return 1;
}
int tcp::unInit()
{
	WSACleanup();
	return 0;
}
int tcp::CreateTcpSkt()
{
	m_Socket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	int i_val = 1;	// ������
	int error = setsockopt(m_Socket, SOL_SOCKET, SO_REUSEADDR, (char*)&i_val, sizeof(i_val));
	if (error == SOCKET_ERROR)
		return FALSE;
 

	return m_Socket;
}

int tcp::Open(int nSock,char* pIP,int nRemotePort)
{
	SOCKADDR_IN addrSrv;  
	addrSrv.sin_addr.S_un.S_addr = inet_addr(pIP); //�Ѿ��������ֽڸ�ʽ     
	addrSrv.sin_family = AF_INET;  
	addrSrv.sin_port = htons(nRemotePort);  
	int nRet = connect(nSock, (SOCKADDR*)&addrSrv, sizeof(SOCKADDR));  
	if ( nRet  == SOCKET_ERROR )
	{
		DWORD dwErr = GetLastError();
		return -1;
	}

	m_isConnect = TRUE;

	return 1;
 




	//////////////////////////////////////////////////////////////////////////
	char cBuf[100] = {0};  
	strcpy(cBuf,"hello, world!");
	send(nSock, cBuf, strlen(cBuf)+1, 0);  
	printf(" %s Says: %s\n", "client", cBuf);

	
	int nLen = 0;  
	do{  

		memset(cBuf, 0, 100 );
		nLen = recv(nSock, cBuf, 100, 0);  
		printf("%s Says: %s\n", "Server", cBuf);     // ������Ϣ  
		
		send(nSock, cBuf, strlen(cBuf)+1, 0);  
		printf(" %s Says: %s\n", "client", cBuf);

		if( 0 == strcmp(cBuf, "goodbye") )
		{
			break;
		}

	}while(nLen); 

	 closesocket(nSock);  

	return 1;
}


int tcp::Read( BYTE* pBuffer, int readSize, UINT nTimeOut)
{
	int selectState;
	int recvSize;

	if ( !pBuffer || !m_isOpen)
		return -1;

	selectState = Select( SELECT_MODE_READY, nTimeOut);
	if ( SELECT_STATE_TIMEOUT == selectState)
		return 0;

	if ( SELECT_STATE_READY == selectState)
	{
		recvSize = recv(m_Socket, (char*)pBuffer, readSize, 0);
		if (recvSize <= 0)
			return -1;
		return recvSize;
	}
	return -1;
}

int tcp::Select(int mode, int timeoutUsec) 
{
	fd_set fdset;
	fd_set *readSet, *writeSet;
	timeval selectTimeout;
	int ret;

	selectTimeout.tv_sec  = 0;
	selectTimeout.tv_usec = timeoutUsec;

	FD_ZERO (&fdset);
	FD_SET  (m_Socket, &fdset);

	readSet  = ( mode & SELECT_MODE_READY) ? &fdset : NULL;
	writeSet = ( mode & SELECT_MODE_WRITE) ? &fdset : NULL;

	ret = select ( (int)m_Socket + 1, readSet, writeSet, NULL, &selectTimeout);
	if (ret == 1) 
		return SELECT_STATE_READY;

	if (ret == SOCKET_ERROR) 
	{
		if ( errno == EINTR)
			return SELECT_STATE_ABORTED;

		return SELECT_STATE_ERROR;
	} 

	return SELECT_STATE_TIMEOUT;
}
long tcp::GetSokcetPort( int sock, int *port )
{
	long lret = -1;
	sockaddr_in addr;
	int nlen;
	nlen = sizeof addr;
	addr.sin_port = 0;
	*port = 0;
	if(getsockname(sock, (struct sockaddr*)&addr, &nlen) < 0)
	{
		lret = -1;
	}
	else
	{
		lret = 0;
		*port = addr.sin_port;
	}
	return lret;
}