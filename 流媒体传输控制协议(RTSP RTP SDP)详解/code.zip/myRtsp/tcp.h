/**
 *	�ҵĲ��ͣ�http://blog.csdn.net/machh
 *  ��Ƶ�γ̣�http://edu.csdn.net/course/detail/2635
 *	QQȺ:576912843
 *	mark:����ֻ������ѧϰʹ��
 */

#pragma once

#include <winsock2.h>

//using namespace std;

// select mode 
#define SELECT_MODE_READY		0x001
#define SELECT_MODE_WRITE		0x002

// select return codes 
#define SELECT_STATE_READY         0
#define SELECT_STATE_ERROR         1
#define SELECT_STATE_ABORTED       2
#define SELECT_STATE_TIMEOUT       3


#define INVALID_SOCKET  (SOCKET)(~0)
#define SOCKET_ERROR            (-1)


class tcp
{
public:
	tcp(void);
	virtual ~tcp(void);

	//������;
	 int Init();

	 int unInit();

	 int CreateTcpSkt();

	 int Open(int nSock,char* pIP,int nRemotePort);

	 virtual int Read( BYTE* pBuffer, int readSize, UINT nTimeOut = 500000);

	 int Select(int mode, int timeoutUsec) ;

	 long GetSokcetPort( int sock, int *port );
protected:
	bool m_bInit;
	bool m_isOpen;
	int m_Socket;
	bool m_isConnect;
};
