/**
 *	�ҵĲ��ͣ�http://blog.csdn.net/machh
 *  ��Ƶ�γ̣�http://edu.csdn.net/course/detail/2635
 *	QQȺ:576912843
 *	mark:����ֻ������ѧϰʹ��
 */

#pragma once

#include <winsock2.h>
#include <string>

#include "tcp.h"
using namespace std;

#define  P_NAME  "User-Agent: machh(http://blog.csdn.net/machh)"
#define  PP_CRLF "\r\n"

class MyRtspClient : public tcp
{
public:
	MyRtspClient(void);
	~MyRtspClient(void);


	BOOL OpenStream(char * pURL);

	INT ReadLine(string* pStr, UINT strMaxSize, UINT nTimeOut = 500000); //0.5 sec

	//��ȡ����;
	long ReadSocket(int sock, char *buf, int len, int timeout);

	//������������;
	long SendRTSPCmd(const char *cmd );

	//rtsp�������;
	BOOL ParseMrl(string mrl, string* pPreSuffix, string* pSuffix, int* pPort);

	int RecvResponse(string& pStr);
	BOOL GetDescribe( string &resp );
	string GetTrackID( string &sdp );
	string GetSessionID( string &sdp );

	//����rtsp��������;
	char * GetRTSPCmd(const char *);
	char * GetOptionCmd(char *url);
	char * GetDescribeCmd(char *url);
	char * GetSetupCmd(char *url,char*pTrackID, int port1, int port2);
	char * GetPlayCmd(char *url, char *session, char *range);

	char * GetTearDownCmd();


protected:

	int m_nPort;
	std::string m_strURL;
	std::string m_strSvrIp;
	std::string m_session;
	int m_nCSeq;

};


