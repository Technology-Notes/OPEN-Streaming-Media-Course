/**
 *	�ҵĲ��ͣ�http://blog.csdn.net/machh
 *  ��Ƶ�γ̣�http://edu.csdn.net/course/detail/2635
 *	QQȺ:576912843
 *	mark:����ֻ������ѧϰʹ��
 */
#ifndef __CAUDIO_PLAY_H__
#define __CAUDIO_PLAY_H__
#include <windows.h>
#include "typedef.h"

#include <mmsystem.h>

class CAudioPlay
{
public:
	CAudioPlay(void);
	~CAudioPlay(void);
	//machh
	unsigned long samplerate;
	unsigned char channels;
	bool		  m_bStop;

public:
	bool    startAudioPlay(int devIndex, int nSampleRate, int nChannal);
	void    stopAudioPlay(void);

	int     setVolume(int volume);
	int     getVolume();

	void    playAudio(unsigned char * pData, int len);
	void    waveOutProc();
	void    onClose();

private:
	WAVEHDR   * allocateBlocks(int size, int count) ;
	void        freeBlocks(WAVEHDR* blockArray);
	void        writeAudio(unsigned char * data, int size);
	

#define BLOCK_SIZE		        320 
#define BLOCK_COUNT		        20
#define MAX_AUDIO_FRAME_SIZE    192000
#define OUT_BUF_LEN             (16 * 1024)

private:
	HWAVEOUT            m_hWaveOut;
	WAVEHDR 		  * m_pWaveBlocks;
	bool				m_bAudioInited;
	short				m_pOutputBuf[OUT_BUF_LEN];
	
	CRITICAL_SECTION	m_waveCriticalSection;
	volatile int		m_waveFreeBlockCount;
	int					m_waveCurrentBlock;
};

#endif // __CAUDIO_PLAY_H__



