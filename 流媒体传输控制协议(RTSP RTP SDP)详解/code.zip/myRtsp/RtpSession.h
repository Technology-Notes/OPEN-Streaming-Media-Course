/**
 *	�ҵĲ��ͣ�http://blog.csdn.net/machh
 *  ��Ƶ�γ̣�http://edu.csdn.net/course/detail/2635
 *	QQȺ:576912843
 *	mark:����ֻ������ѧϰʹ��
 */

#pragma once
#include <string>
#include "winsock2.h"
#include "AudioVideoUilitys.h"


#define MSG_PLAY_FINISH		(WM_USER+1221)

#ifndef CLOSE_SKT
#define CLOSE_SKT(s){if (s > 0) { ::shutdown(s, 0x02); ::closesocket (s);s = -1;}}	
#endif


#ifndef _RTPDATA_CB_
#define _RTPDATA_CB_
typedef void (*RtpDataCallback)(int nMediaType,unsigned char *pData,unsigned long nLen,void* lpContext);

#endif

class RtpSession
{
public:
	explicit RtpSession(int nStreamType,int nSubType );

	void Destroy();
	void close();
	int  connect( const std::string & ip, int port);
	bool isOpen(){ return m_bStop; };
	
	int SetDataCallBack( RtpDataCallback pFunc, void *pContent);
	bool StartReceive();

	int GetMediaMainType() { return m_nMediaType;}

protected:

	void ToFrame( char * buffer ,int nRtpLen );
	void RunRtpRecvThread();
	SOCKET CreateRtpSck();
	SOCKET m_socket;

	RtpSession(void);
	~RtpSession(void);

private:
	   
	HANDLE m_event;
//	CEvent m_event;
	bool m_bStop;
	bool m_bRunning;
	int m_nLocalPort;
	int m_nMediaType;
	int m_nSubMediaType;
	std::string m_strLocalIP;

	std::string m_pRemoteIP;
	int m_nRemotePort;
	int m_nPreLinkTime;

	/**	�ص����� */
	RtpDataCallback m_pRtpDataFunc;
	/** �û�ָ�� */
	void * m_pUserData;
 

	void * m_pEventCtx;

	HANDLE m_hThread;
	DWORD m_ThreadID;
	static DWORD WINAPI ThreadFunc(LPVOID lpParameter);

};

