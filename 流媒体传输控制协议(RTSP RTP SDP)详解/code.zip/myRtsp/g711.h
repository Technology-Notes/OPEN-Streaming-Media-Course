
#ifndef _G711_H_
#define _G711_H_


/*
* u-law, A-law and linear PCM conversions.
*/
#define	SIGN_BIT	(0x80)		/* Sign bit for a A-law byte. */
#define	QUANT_MASK	(0xf)		/* Quantization field mask. */
#define	NSEGS		(8)		/* Number of A-law segments. */
#define	SEG_SHIFT	(4)		/* Left shift for segment number. */
#define	SEG_MASK	(0x70)		/* Segment field mask. */
#define	BIAS		(0x84)		/* Bias for linear code. */

#define OUT 
#define IN

//--------------------------------------------------------
//-- Name  ����g711a   : 
//-- Describle:  
//-- param[out]       amp:  ���pcm����
//-- param[in] g711a_data:  �����g711����
//-- param[in]: 
//--------------------------------------------------------
int g711a_decode(OUT short amp[], IN const unsigned char g711a_data[], int g711a_bytes);

//--------------------------------------------------------
//-- Name  ����g711u   : 
//-- Describle:  
//-- param[out]       amp:  ���pcm����
//-- param[in] g711a_data:  �����g711����
//-- param[in]g711u_bytes:  �������ݵĳ���
//--------------------------------------------------------
int g711u_decode(OUT short pcm[], IN const unsigned char g711u_data[], int g711u_bytes);


//--------------------------------------------------------
//-- Name  pcm����g711a   : 
//-- Describle:  
//-- param[in]: 
//-- param[in]: 
//--------------------------------------------------------
int g711a_encode(OUT unsigned char g711_data[], IN const short pcm[], int len);

int g711u_encode(OUT unsigned char g711_data[], IN const short pcm[], int len);

#endif


