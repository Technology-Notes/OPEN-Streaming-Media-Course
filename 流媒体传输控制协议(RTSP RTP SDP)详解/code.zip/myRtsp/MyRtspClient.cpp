#include "StdAfx.h"
#include "MyRtspClient.h"


#include <windows.h>
#include <commctrl.h>

#include <MMSystem.h>

#include <stdio.h>
#include <stdlib.h>
#include <tchar.h>


#pragma comment(lib, "ws2_32.lib")


#ifndef _WIN32_WCE
#define WIN32_LEAN_AND_MEAN
#endif

#define   SIO_RCVALL               _WSAIOW(IOC_VENDOR,1)   
#define   SIO_RCVALL_MCAST         _WSAIOW(IOC_VENDOR,2)   
#define   SIO_RCVALL_IGMPMCAST     _WSAIOW(IOC_VENDOR,3)   
#define   SIO_KEEPALIVE_VALS       _WSAIOW(IOC_VENDOR,4)   
#define   SIO_ABSORB_RTRALERT      _WSAIOW(IOC_VENDOR,5)   
#define   SIO_UCAST_IF             _WSAIOW(IOC_VENDOR,6)   
#define   SIO_LIMIT_BROADCASTS     _WSAIOW(IOC_VENDOR,7)   
#define   SIO_INDEX_BIND           _WSAIOW(IOC_VENDOR,8)   
#define   SIO_INDEX_MCASTIF        _WSAIOW(IOC_VENDOR,9)   
#define   SIO_INDEX_ADD_MCAST      _WSAIOW(IOC_VENDOR,10)   
#define   SIO_INDEX_DEL_MCAST      _WSAIOW(IOC_VENDOR,11)  



MyRtspClient::MyRtspClient(void)
{
}

MyRtspClient::~MyRtspClient(void)
{
}


/*
 * OpenStream
 */
BOOL MyRtspClient::OpenStream(char * pURL)
{
	m_strURL = pURL;

	int nRet = Init();

	int nsck = CreateTcpSkt();

	string pSuffix;
	BOOL bOk = ParseMrl(pURL, &m_strSvrIp, &pSuffix, &m_nPort);
	if ( !bOk )
		return FALSE;
	
	if( Open(nsck, (char*)m_strSvrIp.c_str(), m_nPort) < 0 )
		return FALSE;


	return TRUE;
}
//////////////////////////////////////////////////////////////////////////

//SessionID
string MyRtspClient::GetSessionID( string &strResp )
{
	string::size_type  iFind;
	// m_Session
	string strfield = "Session:";
	iFind = strResp.find(strfield);
	if ( iFind != -1 )
	{
		strResp.erase(0, iFind + strfield.size() );
		m_session = strResp ;
		iFind = strResp.find( PP_CRLF);
		string lenfix;
		if ( iFind != -1 )
		{
			m_session = strResp.substr(0, iFind - 0);	
		}

		string::size_type iFind2 = m_session.find(";");
		if ( iFind2 != string::npos )
		{
			m_session= m_session.substr( 0, iFind2 );
		}
	}
	else return "";

	return m_session;
}

// trackid
string MyRtspClient::GetTrackID( string &sdp )
{
	string::size_type  iFind;
	iFind = sdp.find( "m=audio" );

	string strTrackID;
	string strfield = "a=control:";

	if (iFind != string::npos)
	{
		iFind = sdp.find(strfield,iFind );
		if (iFind != string::npos)
		{
			sdp.erase(0, iFind + strfield.size() );
			iFind =	sdp.find("\r\n");
			if ( iFind != string::npos )
			{
				strTrackID = sdp.substr( 0, iFind ) ;
			}
		}
	}

	return strTrackID;
}

 char* getLine(char* startOfLine)
 {  
	// returns the start of the next line, or NULL if none  
	for (char* ptr = startOfLine; *ptr != '\0'; ++ptr) 
	{  
		// Check for the end of line: \r\n (but also accept \r or \n by itself):  
		if (*ptr == '\r' || *ptr == '\n') 
		{  
			// We found the end of the line  
			if (*ptr == '\r') 
			{  
				*ptr++ = '\0';  
				if (*ptr == '\n') 
					++ptr;  
			}
			else 
			{  
				*ptr++ = '\0';  
			}  
			return ptr;  
		}  
	}  


	return NULL;  
}  
//sdp
BOOL MyRtspClient::GetDescribe( string & resp )
{
	string::size_type iFind, iFindEnd;

	int nMsgLen = resp.size();
	// Content-Length: 512
	string strfield = "Content-Length";
	iFind = resp.find( strfield );
	if (iFind == string::npos)
	{
		strfield = "Content-length";
		iFind = resp.find( strfield );
		if (iFind == string::npos)
			return false;
	}

	resp.erase(0, iFind + strfield.size() );	//remove Content-Length
	iFind = resp.find_first_not_of(':');		//remove ':'
	if (iFind >= 0)
		resp.erase(0, iFind);

	int nLen = 0;
	iFind = resp.find( PP_CRLF);
	string strTemp;
	if (iFind >= 0)
	{
		strTemp = resp.substr(0, iFind - 0);	
		nLen = atoi( strTemp.c_str() );		//����
		resp.erase(0, iFind);
	}

	iFind = resp.find( "m=audio");
	strTemp = resp.substr(iFind, resp.size() );

	iFind = strTemp.find( "a=rtpmap:");
	strTemp.erase(0, iFind);

	char * pLine = (char*)strTemp.c_str();
	pLine = getLine( pLine );

	iFindEnd = strTemp.find(PP_CRLF);

	strTemp = strTemp.substr(iFind, iFindEnd );
	
	//m=audio 0 RTP/AVP 8
	//a=rtpmap:8 PCMA/8000/1

}
int MyRtspClient::RecvResponse(string& pStr)
{
	printf( "---->> \r\n" );
	pStr.clear();
	char c;
	int iRead = 0;
	BYTE szBuf[256] = {0};
	while( iRead != -1)
	{
		memset(szBuf, 0, 256 );
		iRead = tcp::Read( szBuf, 256,   500000 );
		if (iRead <= 0)
			break;

		pStr.append((char*)szBuf, iRead);// += szBuf;
	}

	printf( pStr.c_str() );
	return (UINT)pStr.size();
}

//
INT MyRtspClient::ReadLine( string* pStr, UINT strMaxSize, UINT nTimeOut)
{
	char c;
	int iRead = 0;

	if ( !m_isConnect || !pStr )
		return -1;

	pStr->erase( pStr->begin(), pStr->end());

	while( iRead != -1)
	{
		iRead = tcp::Read( (PBYTE)&c, 1, nTimeOut );
		if (iRead <= 0)
			continue;

		if ( c == '\r' || c == '\n')
			break;

		if ( iRead == 1  && pStr->size() <= strMaxSize)
			pStr->append(1, c);
	}

	if ( iRead <= 0 )
		return -1;

	return (UINT)pStr->size();
}

long MyRtspClient::ReadSocket(int sock,  char *buf, int len, int timeout )
{
	long lret ;
	fd_set fr;
	timeval tm;
	tm.tv_sec = timeout;
	tm.tv_usec = 0;


	FD_ZERO(&fr);
	fr.fd_count = 1;
	fr.fd_array[0] = sock;

	lret = select(sock, &fr, NULL, NULL, &tm);
	if( lret > 0)
	{
		lret = recv(sock, buf, len, 0);
		if(lret == SOCKET_ERROR)
		{


		}
		else if(lret > 0)
		{
		}
	}


	return lret;
}


//
long MyRtspClient::SendRTSPCmd( const char *cmd )
{
	long lret;
	int ilen;
	ilen = strlen(cmd);
	lret = send( m_Socket, cmd, ilen,0);
	if( lret == SOCKET_ERROR)
	{
		lret = WSAGetLastError();
	}
	printf( cmd );
	return lret;
}


//
char * MyRtspClient::GetRTSPCmd( const char * szName)
{
	char *str = NULL;
	char const*  cmdFmt = NULL;
	if(!strcmp(szName, "OPTIONS"))
	{
		cmdFmt =
			"OPTIONS %s RTSP/1.0\r\n"
			"CSeq: %d\r\n"
			"%s"
			"%s"
			"\r\n";
	}
	else if(!strcmp(szName, "PLAY"))
	{
		cmdFmt ="PLAY %s RTSP/1.0\r\n"
			"CSeq: %d\r\n"
			"Session:%s\r\n"
			"Range: npt=0.000-%s\r\n"
			"%s"
			"%s"
			"%s"
			"\r\n";
	}
	else if(!strcmp(szName, "PAUSE"))
	{
		cmdFmt =
			"PAUSE %s RTSP/1.0\r\n"
			"CSeq: %d\r\n"
			"Session: %s\r\n"
			"%s"
			"%s"
			"\r\n";
	}
	else if(!strcmp(szName, "SET_PARAMETER"))
	{
		cmdFmt =
			"SET_PARAMETER %s RTSP/1.0\r\n"
			"CSeq: %d\r\n"
			"Session: %s\r\n"
			"%s"
			"%s"
			"Content-length: %d\r\n\r\n"
			"%s: %s\r\n";
	}
	else if(!strcmp(szName, "GET_PARAMETER"))
	{
		cmdFmt =
			"GET_PARAMETER %s RTSP/1.0\r\n"
			"CSeq: %d\r\n"
			"Session: %s\r\n"
			"%s"
			"%s"
			"Content-type: text/parameters\r\n"
			"Content-length: %d\r\n\r\n"
			"%s\r\n";
	}
	else if(!strcmp(szName, "TEARDOWN"))
	{
		cmdFmt =
			"TEARDOWN %s RTSP/1.0\r\n"
			"CSeq: %d\r\n"
			"Session: %s\r\n"
			"%s"
			"%s"
			"\r\n";
	}
	else if(!strcmp(szName, "DESCRIBE"))
	{
		cmdFmt =
			"DESCRIBE %s RTSP/1.0\r\n"
			"CSeq: %d\r\n"
			"%s"
			"%s"
			"%s"
			"\r\n";
	}
	else if(!strcmp(szName, "ANNOUNCE"))
	{
		cmdFmt =
			"ANNOUNCE %s RTSP/1.0\r\n"
			"CSeq: %d\r\n"
			"Content-Type: application/sdp\r\n"
			"%s"
			"Content-length: %d\r\n\r\n"
			"%s";
	}
	else if(!strcmp(szName, "SETUP"))
	{
		cmdFmt ="SETUP %s"
			"CSeq: %d\r\n"
			"%s"
			"%s"
			"%s"
			"%s"
			"\r\n";
	}

	printf( "\r\n -----   %s ---------------------\r\n",szName );
	str = (char*)cmdFmt;
	return str;
}


//
char * MyRtspClient::GetOptionCmd( char *url )
{
	int nlen, iret=0;
	char *ss;
	char *s = GetRTSPCmd("OPTIONS");

	nlen = strlen(s);
	iret += nlen ;
	iret += strlen(url);
	iret += strlen(P_NAME) ;
	iret += 200;
	ss = (char*)malloc(iret);

	m_nCSeq =1;
	sprintf(ss, s, url, m_nCSeq, P_NAME, PP_CRLF);

	return ss;
}

//
char * MyRtspClient::GetTearDownCmd()
{
	int nlen, iret;
	char *ss;
	char *s = GetRTSPCmd("TEARDOWN");

	nlen = strlen(s);
	iret = nlen + m_strURL.size() + strlen(P_NAME) + 200;
	ss = (char*)malloc(iret);

	m_nCSeq++;
	sprintf(ss, s, m_strURL.c_str(), m_nCSeq, m_session.c_str(), P_NAME, PP_CRLF, PP_CRLF);
	return ss;

	return ss;
}


//
char * MyRtspClient::GetDescribeCmd( char *url )
{
	char *ss;
	char *s = GetRTSPCmd("DESCRIBE");

	int nlen = strlen(s);
	nlen = nlen + strlen(url) + strlen(P_NAME) + 200;
	ss = (char*)malloc(nlen);

	m_nCSeq++;
	sprintf(ss, s, url, m_nCSeq, P_NAME, PP_CRLF, PP_CRLF);

	return ss;
}
//
char * MyRtspClient::GetPlayCmd( char *url , char *session, char *range)
{
	int nlen, iret;
	char *ss;
	char *s = GetRTSPCmd("PLAY");
 
	nlen = strlen(s);
	iret = nlen + strlen(url) + strlen(P_NAME) + 200;
	ss = (char*)malloc(iret);

	m_nCSeq++;
	sprintf(ss, s, url, m_nCSeq, session, "", P_NAME, PP_CRLF, PP_CRLF);

	return ss;
}

//
char * MyRtspClient::GetSetupCmd( char *url ,char*pTrackID, int port1, int port2)
{
	int  iret=0;
	char *ss;
	char *s = GetRTSPCmd("SETUP");
	int nlen = strlen(s);

	iret += nlen ;
	iret += strlen(url);
	iret += strlen(P_NAME) ;
	iret += 200;
	ss = (char*)malloc(iret);

	char buf[128] = {0};
	char buf2[128] = {0};
	if(port1 == 0)
		strcpy(buf, "\r\nTransport: RTP/AVP/TCP;unicast;interleaved=0-1");
	else
		sprintf_s(buf, "\r\nTransport: RTP/AVP;unicast;client_port=%d-%d", (port1), (port2));
	
	sprintf_s(buf2, "%s/%s RTSP/1.0\r\n", url, pTrackID );

	m_nCSeq++;
	sprintf(ss, s, buf2, m_nCSeq,  P_NAME, buf, PP_CRLF, PP_CRLF);

	return ss;
}


BOOL MyRtspClient::ParseMrl(string mrl, string* pPreSuffix, string* pSuffix, int* pPort)
{
	int port;
	string preSuffix;
	string suffix;
	string::size_type iFind, iFindEnd;
	// ����-url   
	iFind = mrl.find("rtsp://");
	if (iFind == string::npos)
	{
		printf("rtsp: bad url: %s\n", mrl);
		return false;
	}
	mrl.erase(0, iFind + 7);	//remove "rtsp://"

	port = 554;	//��׼rtspЭ��˿�
	iFind = mrl.find(':');
	if (iFind != string::npos)
	{
		iFindEnd = mrl.find('/', iFind);
		if (iFindEnd != string::npos)
		{
			port = atoi( mrl.substr( iFind + 1, iFindEnd - iFind).c_str() );
			mrl.erase( iFind, iFindEnd - iFind );
		}
	}

	iFind = mrl.find('/');
	if ( iFind != string::npos)
	{
		preSuffix = mrl.substr(0, iFind - 0);
		mrl.erase( 0, iFind + 1);

		iFind = mrl.find('/');
		if ( iFind != string::npos )
		{
			mrl.erase(0, iFind + 1);
		}
		suffix = mrl;
	}
	else preSuffix = mrl;

	if (pPreSuffix)
		*pPreSuffix = preSuffix;

	if (pSuffix)
		*pSuffix = suffix; 

	if (pPort)
		*pPort = port;

	return true;
}



//