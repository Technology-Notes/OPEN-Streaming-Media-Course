/**
 *	�ҵĲ��ͣ�http://blog.csdn.net/machh
 *  ��Ƶ�γ̣�http://edu.csdn.net/course/detail/2635
 *	QQȺ:576912843
 *	mark:����ֻ������ѧϰʹ��
 */
#include "stdafx.h"
#include "process.h"

#include "MyRtspClient.h"

#include "tcp.h"
#include "RtpSession.h"
#include "AudioPlay.h"
#include "g711.h"


#define SAFE_FREE(x) { if(x) free(x); x=NULL;}
 

CAudioPlay audioPlayer;
RtpSession* pRtpSession = NULL;

unsigned int m_ThreadID2 =0;
HANDLE hHandle = 0;
unsigned int __stdcall Thread1(PVOID param)
{

	MSG msg;
	int nTimeCnt = 0;					
	UINT idTimer  = SetTimer(NULL, NULL, 1000, NULL);
	PeekMessage(&msg, NULL, 0, 0, PM_REMOVE);
	while (GetMessage(&msg, NULL, 0, 0))
	{
		switch(msg.message)
		{
		case WM_TIMER:
			{
				nTimeCnt++;
				printf("%d ",nTimeCnt );
				if ( nTimeCnt >15 )
					return 1;
			}
			break;
		case WM_QUIT:
			KillTimer(NULL,idTimer);
			break;
		default:
			break;
		}
	}
	return 0;
}


void  AudioRtpDataCallBack( int nMediaType,unsigned char *pData,unsigned long nLen, void* lpContext )
{
// 	//�˴��ص���������Ƶ���� �Ѿ�ȥ����rtpͷ��Ϣ
  	short	szPcmBuf[OUT_BUF_LEN];
  	int nPcmLen = 0;

	nPcmLen = g711a_decode( (short*)szPcmBuf,  pData, nLen );
	audioPlayer.playAudio((BYTE*) szPcmBuf, nPcmLen );
}

int _tmain(int argc, _TCHAR* argv[])
{
	MyRtspClient myClient;

	string strResp;

	char * pUrl = "rtsp://192.168.1.88:554/11";    //"rtsp://10.0.20.97/1.aac" ;
	bool bOk =	myClient.OpenStream( pUrl );
	if ( bOk )
	{
		char * pCmd = myClient.GetOptionCmd( pUrl );
		myClient.SendRTSPCmd( pCmd );
		SAFE_FREE( pCmd )

		myClient.RecvResponse( strResp );
		if ( strResp.find("RTSP/1.0 200 OK") == -1)
			return FALSE;

		pCmd = myClient.GetDescribeCmd( pUrl );
		myClient.SendRTSPCmd( pCmd );
		SAFE_FREE( pCmd )

		myClient.RecvResponse( strResp );
		//sdp
		myClient.GetDescribe( strResp );

		string strTrackID;
		strTrackID = myClient.GetTrackID( strResp );

		int m_nLocalRtpPort = 6000;
		std::string strMediumName = "audio";
		if ( "audio" == strMediumName )
		{
			std::string m_strACoderName = "PCMA";// = myClient.codecName();
			if (  0== strcmp(m_strACoderName.c_str(), "PCMA")) 
			{
				//set up
				pCmd = myClient.GetSetupCmd( pUrl,(char*)strTrackID.c_str(),m_nLocalRtpPort,m_nLocalRtpPort+1 );
				myClient.SendRTSPCmd( pCmd );
				SAFE_FREE( pCmd )

				myClient.RecvResponse( strResp );

				string::size_type iFind = strResp.find("200 OK");
				if (iFind != string::npos)
				{
					string sessionID = myClient.GetSessionID( strResp );
					if ( sessionID.size()> 1 )
					{
						// �������ݽ���Ĺ����߳�
						hHandle = (HANDLE)_beginthreadex( NULL, 0, &Thread1, /*this*/0, 0, &m_ThreadID2 );
						
						pRtpSession = new RtpSession( MEDIA_AUDIO ,MEDIA_SUBTYPE_PCMU );
						pRtpSession->SetDataCallBack( AudioRtpDataCallBack,NULL );

						pRtpSession->connect( "", m_nLocalRtpPort );//6004 ?

						int audioSamprate =  8000;		//;	44100	//��Ƶ������
						int audioChannel = 1;			//��Ƶ���� 1��2
						int audioBit = 16;	
						audioPlayer.startAudioPlay(0, audioSamprate, audioChannel ); 
						//
						pCmd = myClient.GetPlayCmd( pUrl,(char*)sessionID.c_str(), NULL );
						myClient.SendRTSPCmd( pCmd );
						myClient.RecvResponse( strResp );
						SAFE_FREE( pCmd )
					}


					WaitForSingleObject( hHandle, INFINITE );

					pCmd = myClient.GetTearDownCmd();
					myClient.SendRTSPCmd( pCmd );
					myClient.RecvResponse( strResp );
					SAFE_FREE( pCmd )
				}
			}
		}
	}

	system("pause");

	return 1;
}




