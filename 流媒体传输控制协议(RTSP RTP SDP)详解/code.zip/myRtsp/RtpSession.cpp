/**
 *	�ҵĲ��ͣ�http://blog.csdn.net/machh
 *  ��Ƶ�γ̣�http://edu.csdn.net/course/detail/2635
 *	QQȺ:576912843
 *	mark:����ֻ������ѧϰʹ��
 */
#include "stdafx.h"
#include "RtpSession.h"
 
#include "winsock2.h"

RtpSession::RtpSession(void)
{
	m_bStop = false;
	m_bRunning = false;
	m_nMediaType = -1;
	m_pUserData = NULL;
	m_pRtpDataFunc = NULL;

}
RtpSession::RtpSession(int nStreamType,int nSubType )
{
	m_pRtpDataFunc = NULL;
	m_bStop = false;
	m_bRunning = false;

	m_pUserData = NULL;

	m_nPreLinkTime = 0;
	m_nSubMediaType = nSubType;
	m_nMediaType = nStreamType;

}

RtpSession::~RtpSession(void)
{
}
//

int RtpSession::SetDataCallBack(RtpDataCallback pFunc, void *pContent)
{
	m_pRtpDataFunc = pFunc;
	m_pUserData = pContent;
	return 0;
}
int RtpSession::connect(const std::string & ip, int port)
{
	m_nLocalPort = port;
	m_strLocalIP = ip;

	m_event = CreateEvent(NULL, FALSE, FALSE, NULL); 

	m_hThread = CreateThread(0,0,ThreadFunc,this,0,&m_ThreadID );

	return 1;
}
/*
** ���+���� �߳�
*/
DWORD WINAPI RtpSession::ThreadFunc(LPVOID lpParameter)
{
	RtpSession *pthis = (RtpSession *)lpParameter;

	DWORD dwID = GetCurrentThreadId();

	pthis->StartReceive();

	return 0;
}

void RtpSession::Destroy()
{
	close();


	delete this;
}
void RtpSession::close()
{
	m_bStop = true; 

	if( m_bRunning )
	{
		WaitForSingleObject( m_hThread,INFINITE );
		CloseHandle( m_hThread );
		m_hThread = 0;
	}

	if ( m_bRunning )
	{
		TerminateThread( m_hThread, 7777 );
		//CloseHandle( m_hThread );
		m_hThread = 0;
		m_bRunning = false;
	}
	return ;
}


enum _EVENT_TYPES{
	SP_NETWORK,
	SP_STREAM=100,
};

bool RtpSession::StartReceive()
{
	struct sockaddr_in remote;
	int fromlen = sizeof(remote);
	std::string remoteIp;
	m_bRunning = false;
	// m_event.ResetEvent();

	SOCKET socket = CreateRtpSck();
	if ( socket<0 )
		return false;

	RTP_HEADER* pRtpHead = NULL;
	int nTimeOutCnt = 0;
	while ( !m_bStop )
	{
		char buffer[1500]="\0";
		int nRtpLen = recvfrom( socket,buffer,sizeof(buffer),0,(struct sockaddr*)&remote,&fromlen);
		if ( nRtpLen != SOCKET_ERROR )
		{	
			pRtpHead = (RTP_HEADER*)buffer;
			if ( !m_pRtpDataFunc )
				break;

			m_bRunning = true;
			ToFrame( buffer,nRtpLen );
		} 
		else  {
			++nTimeOutCnt;
		}
		
		if ( nTimeOutCnt >= 200 )// ����100����ճ�ʱ/500ms
			break;
	}
		
	closesocket( socket );
 
	m_bRunning = FALSE;
	m_bStop = TRUE ;


	return TRUE;
}

void RtpSession::ToFrame( char * buffer , int nRtpLen )
{
	int nOutLen = 0;
	RTP_HEADER* pRtpHead = (RTP_HEADER*)buffer;
	if ( H264 == pRtpHead->payloadtype && MEDIA_SUBTYPE_H264 == m_nSubMediaType )
	{
	
	}

	else if (  MEDIA_AUDIO == m_nMediaType)
	{
		if( m_pRtpDataFunc)
			m_pRtpDataFunc( MEDIA_AUDIO,(BYTE*)buffer+RTP_HEADER_LEN, nRtpLen-RTP_HEADER_LEN, m_pUserData );
	}
}

SOCKET RtpSession::CreateRtpSck()
{
	WSADATA wsaData;
	int iErrorCode;
	if ( WSAStartup( MAKEWORD(2,1),&wsaData)) //����Windows Sockets DLL
	{ 
		WSACleanup();
		return -1;
	}

	struct sockaddr_in local;

	local.sin_family = AF_INET;
	local.sin_port= htons( m_nLocalPort );		///�����˿�
	local.sin_addr.s_addr = INADDR_ANY;		///����

	SOCKET socket1 = socket( AF_INET,SOCK_DGRAM,0 );

	int nReuse = 1;// ������
	int error = setsockopt(socket1, SOL_SOCKET, SO_REUSEADDR, (char*)&nReuse, sizeof(nReuse));
	if (error == SOCKET_ERROR)
		return -1;

	nReuse = (int)(1024 * 1024 * 2);//2M Byte 1000Mbps��network��0.01������߿��Խ��յ�1.25MB����
	error = setsockopt( socket1, SOL_SOCKET, SO_RCVBUF, (char*)&nReuse, sizeof(nReuse) );
	if (error == SOCKET_ERROR)
		return -1;

	int nTimeout= 500;//500 ����
	//����ʱ��
//	setsockopt(socket1, SOL_SOCKET,SO_SNDTIMEO, (char *)&nTimeout,sizeof(int));
	//����ʱ��
	setsockopt(socket1,SOL_SOCKET, SO_RCVTIMEO, (char *)&nTimeout,sizeof(int));

	error = bind( socket1,(struct sockaddr*)&local,sizeof(local));
	if (error == SOCKET_ERROR)
		return -1;

	return socket1;
}
