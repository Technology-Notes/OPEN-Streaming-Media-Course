/**
 *	�ҵĲ��ͣ�http://blog.csdn.net/machh
 *  ��Ƶ�γ̣�http://edu.csdn.net/course/detail/2635
 *	QQȺ:576912843
 *	mark:����ֻ������ѧϰʹ��
 */
 
 #include "stdafx.h"

#include "AudioPlay.h"

#pragma comment(lib, "winmm.lib")

void CALLBACK waveOutProc(HWAVEOUT hwo, UINT uMsg, DWORD dwInstance, DWORD dwParam1, DWORD dwParam2) 
{ 
	if (dwInstance == NULL)
		return ;
    
	CAudioPlay * pAudioHandle = (CAudioPlay *)dwInstance;
	if( pAudioHandle->m_bStop )
		return ;

    if (uMsg == WOM_DONE)
    {
	    pAudioHandle->waveOutProc();
    }
    else if (uMsg == WOM_CLOSE)
    {
        pAudioHandle->onClose();
    }
    
    return; 
}


CAudioPlay::CAudioPlay(void)
{
	m_pWaveBlocks			= NULL;
	m_hWaveOut				= NULL;
	m_waveFreeBlockCount	= 0; 
	m_waveCurrentBlock		= 0;
	m_bAudioInited			= false;
	m_bStop					= TRUE;

	::InitializeCriticalSection(&m_waveCriticalSection);
}

CAudioPlay::~CAudioPlay(void)
{
    stopAudioPlay();

	DeleteCriticalSection(&m_waveCriticalSection);
}

bool CAudioPlay::startAudioPlay(int devIndex , int nSampleRate, int nChannal)
{
	MMRESULT ret = 0;
	m_pWaveBlocks = allocateBlocks(BLOCK_SIZE, BLOCK_COUNT); 
	if ( NULL == m_pWaveBlocks )
		goto error;

	WAVEFORMATEX wfx;
	memset(&wfx, 0, sizeof(wfx));
	
	int samplePerSec = nSampleRate;
	wfx.nChannels = nChannal;
	wfx.wBitsPerSample = 16;
	wfx.wFormatTag =  WAVE_FORMAT_PCM;
	wfx.cbSize = 0;
	wfx.nSamplesPerSec =  samplePerSec*0.9749; // 8000
	wfx.nBlockAlign = wfx.nChannels * wfx.wBitsPerSample / 8;  //2;
	//wfx.nAvgBytesPerSec = 8000 * 2;
	wfx.nAvgBytesPerSec = wfx.nSamplesPerSec * wfx.nBlockAlign * 0.9749;

    m_waveFreeBlockCount = BLOCK_COUNT; 
	m_waveCurrentBlock = 0; 

	ret = waveOutOpen(0, devIndex, &wfx, 0, 0, WAVE_FORMAT_QUERY);
	if ( ret != MMSYSERR_NOERROR ) 
		goto error;

    ret = waveOutOpen(&m_hWaveOut, devIndex, &wfx, (DWORD)::waveOutProc, (DWORD)this, CALLBACK_FUNCTION);
	if ( ret != MMSYSERR_NOERROR ) 
		goto error;

	m_bAudioInited = true;
	m_bStop = false;
	
	return true;

error:

	if ( m_pWaveBlocks ) 
	{
		freeBlocks( m_pWaveBlocks );
		m_pWaveBlocks = NULL;
	}

	if ( m_hWaveOut )
	{
		waveOutClose( m_hWaveOut ); 
		m_hWaveOut = NULL;
	}	

	return false;
}

void CAudioPlay::stopAudioPlay(void)
{
	m_bStop = TRUE;
	if ( !m_bAudioInited )
		return;

	if ( m_hWaveOut )
	    waveOutClose(m_hWaveOut); 
}

int CAudioPlay::setVolume(int volume)
{
    if ( volume < 0 || volume > 255 || !m_hWaveOut)
        return -1;
		
	DWORD vol;
	MMRESULT nVol = waveOutGetVolume( m_hWaveOut, &vol);
	MMRESULT Position = 0xFFFF - LOWORD(vol );

    volume = MAKEWORD(volume, volume);
    waveOutSetVolume(m_hWaveOut, volume);

    return 0;
}


int CAudioPlay::getVolume()
{
    if ( !m_hWaveOut )
        return 0;

    DWORD volume = 0;
    waveOutGetVolume(m_hWaveOut, &volume);
    volume = LOBYTE(volume);
    
    return volume;
}

//
void CAudioPlay::playAudio(unsigned char * pData, int len)
{
	writeAudio( pData, len );
	return ;
}
//
void CAudioPlay::writeAudio(unsigned char * data, int size) 
{ 
	if ( !m_pWaveBlocks ) return ;
	if ( m_bStop ) 		  return ;
	
    WAVEHDR * current = &m_pWaveBlocks[m_waveCurrentBlock];
    int remain; 
	MMRESULT result;
	HWAVEOUT hWaveOut = m_hWaveOut;

    while ( size > 0) 
    { 
        if ( current->dwFlags & WHDR_PREPARED)  
            result = waveOutUnprepareHeader(hWaveOut, current, sizeof(WAVEHDR)); 
		
        if ( size < (int)(BLOCK_SIZE - current->dwUser)) 
        { 
            memcpy(current->lpData + current->dwUser, data, size); 
            current->dwUser += size; 
            break; 
        } 

        remain = BLOCK_SIZE - current->dwUser; 
        memcpy( current->lpData + current->dwUser, data, remain); 
        size -= remain; 
        data += remain; 
        current->dwBufferLength = BLOCK_SIZE; 
        result = waveOutPrepareHeader(hWaveOut, current, sizeof(WAVEHDR)); 
        result = waveOutWrite(hWaveOut, current, sizeof(WAVEHDR)); 

        EnterCriticalSection(&m_waveCriticalSection); 
        m_waveFreeBlockCount--; 
        LeaveCriticalSection(&m_waveCriticalSection); 

		// Wait a free block
        while ( !m_waveFreeBlockCount) 
            Sleep(1); 
		// Point to the next block of data
        m_waveCurrentBlock++; 
        m_waveCurrentBlock %= BLOCK_COUNT; 
       
		current = &m_pWaveBlocks[m_waveCurrentBlock]; 
        current->dwUser = 0;
    } 
} 
//
WAVEHDR* CAudioPlay::allocateBlocks(int size, int count) 
{ 
    unsigned char* buffer; 
    int i; 
    WAVEHDR* blocks; 
    SIZE_T totalBufferSize = (size + sizeof(WAVEHDR)) * count; 

    buffer = (unsigned char *)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, (SIZE_T)totalBufferSize);
	if (buffer == NULL)
        return NULL;

    blocks = (WAVEHDR*)buffer; 
    buffer += sizeof(WAVEHDR) * count; 
    
    for ( i = 0; i < count; i++ ) 
    { 
        blocks[i].dwBufferLength = size; 
        blocks[i].lpData = (char *)buffer; 
        buffer += size; 
    } 

    return blocks; 
} 

//
void CAudioPlay::freeBlocks(WAVEHDR* blockArray) 
{ 
    HeapFree( GetProcessHeap(), 0, blockArray ); 
} 

//
void CAudioPlay::waveOutProc()
{
    EnterCriticalSection(&m_waveCriticalSection); 
    m_waveFreeBlockCount++; 
    LeaveCriticalSection(&m_waveCriticalSection); 
}
//
void CAudioPlay::onClose()
{
    if ( m_hWaveOut )
	{	    
        while (m_waveFreeBlockCount < BLOCK_COUNT) 
        {
            Sleep(10); 
        }
        
        for (int i = 0; i < m_waveFreeBlockCount; i++) 
        {
            if (m_pWaveBlocks[i].dwFlags & WHDR_PREPARED) 
            {
                waveOutUnprepareHeader(m_hWaveOut, &m_pWaveBlocks[i], sizeof(WAVEHDR));  
            }
        }        
        
        m_hWaveOut = NULL;
	}

	freeBlocks( m_pWaveBlocks ); 
	m_pWaveBlocks = NULL;
	
	m_hWaveOut = NULL;	
	
	m_bAudioInited = false;
	m_bStop = TRUE;
}



