/**
 *	�ҵĲ��ͣ�http://blog.csdn.net/machh
 *  ��Ƶ�γ̣�http://edu.csdn.net/course/detail/2635
 *	QQȺ:576912843
 *	mark:����ֻ������ѧϰʹ��
 */

#ifndef _BOOLEAN_HH
#define _BOOLEAN_HH

#ifdef   __BORLANDC__
#define Boolean bool
#else
typedef unsigned Boolean;



#define False false
#define FALSE false 
#define True true
#define TRUE true

typedef int             INT;
typedef char			CHAR;

typedef unsigned char   BYTE;
typedef unsigned long	DWORD;



#ifndef UINT32
typedef unsigned int UINT32, *PUINT32 ;
#endif

#ifndef INT32
typedef signed int INT32, *PINT32;
#endif

#ifndef u_long
typedef unsigned long u_long;
#endif

#ifndef ULONG
typedef DWORD ULONG;
#endif


#ifndef UINT
typedef unsigned int        UINT;
#endif

#ifndef PBYTE
typedef unsigned char    *PBYTE;
#endif

#ifndef PCHAR
typedef CHAR *PCHAR, *LPCH, *PCH ;
#endif


#ifndef PCSTR
typedef const char *LPCSTR, *PCSTR;
#endif

#ifndef PVOID
typedef void * PVOID;
#endif

#ifndef INT64
typedef long long   INT64;
#endif

#ifndef SOCKET
typedef  unsigned int SOCKET;
#endif

#ifndef WIN32
#define _atoi64(val)     strtoll(val, NULL, 10)
#endif

#ifndef WIN32
#define _snprintf     snprintf
#endif

#ifndef WIN32
#define closesocket    close
#endif


#endif

#endif
