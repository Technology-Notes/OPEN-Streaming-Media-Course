/**
 *	�ҵĲ��ͣ�http://blog.csdn.net/machh
 *  ��Ƶ�γ̣�http://edu.csdn.net/course/detail/2635
 *	QQȺ:576912843
 *	mark:����ֻ������ѧϰʹ��
 
 */
#ifndef _AUDIO_VIDEO_ULITY__
#define _AUDIO_VIDEO_ULITY__

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define H264 (96)

#define RTP_HEADER_LEN (12)
#define RTP_VERSION 2 
#define BUF_SIZE (1024 * 1024 * 3/2)//(1024 * 500) 

enum {
	MEDIA_VIDEO,
	MEDIA_AUDIO,
};

enum {
	MEDIA_SUBTYPE_H264,
	MEDIA_SUBTYPE_H265,
	MEDIA_SUBTYPE_AAC,
	MEDIA_SUBTYPE_PCMU,
	MEDIA_SUBTYPE_PCMA,
};

typedef unsigned int u_int32;

	/*
	0                   1                   2                   3
	0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
	+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
	|V=2|P|X|  CC   |M|     PT      |       sequence number         |
	+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
	|                           timestamp                           |
	+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
	|           synchronization source (SSRC) identifier            |
	+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+
	|            contributing source (CSRC) identifiers             |
	|                             ....                              |
	+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
							rtp head
    */

	//intel ��cpu ��intelΪС���ֽ��򣨵Ͷ˴浽�׵�ַ�� ��������Ϊ����ֽ��򣨸߶˴浽�͵�ַ��
	/*intel ��cpu �� �߶�->csrc_len:4 -> extension:1-> padding:1 -> version:2 ->�Ͷ�
	 ���ڴ��д洢 ��
	 ��->4001���ڴ��ַ��version:2
	     4002���ڴ��ַ��padding:1
		 4003���ڴ��ַ��extension:1
	 ��->4004���ڴ��ַ��csrc_len:4

     ���紫����� �� �߶�->version:2->padding:1->extension:1->csrc_len:4->�Ͷ�  (Ϊ��ȷ���ĵ�������ʽ)

	 ��������ڴ� ��
	 ��->4001���ڴ��ַ��version:2
	     4002���ڴ��ַ��padding:1
	     4003���ڴ��ַ��extension:1
	 ��->4004���ڴ��ַ��csrc_len:4
	 �����ڴ���� ���߶�->csrc_len:4 -> extension:1-> padding:1 -> version:2 ->�Ͷ� ��
	 ����
	 unsigned char csrc_len:4;        // expect 0 
	 unsigned char extension:1;       // expect 1
	 unsigned char padding:1;         // expect 0 
	 unsigned char version:2;         // expect 2 
	*/

//rtp ��ͷ
typedef struct 
{
	/**//* byte 0 */
	unsigned char csrc_len:4;        /**//* expect 0 */
	unsigned char extension:1;        /**//* expect 1, see RTP_OP below */
	unsigned char padding:1;        /**//* expect 0 */
	unsigned char version:2;        /**//* expect 2 */
	
	/**//* byte 1 */
	unsigned char payloadtype:7;        /**//* RTP_PAYLOAD_RTSP */
	unsigned char marker:1;        /**//* expect 1 */
	
	/**//* bytes 2, 3 */
	unsigned short seq_no;  //16          
	
	/**//* bytes 4-7 */
	unsigned  long timestamp;        
	/**//* bytes 8-11 */
	unsigned long ssrc;            /**//* stream number is used here. */

} RTP_HEADER;		//

#ifndef _tag_RTP_HEADER
#define _tag_RTP_HEADER
typedef struct _tag_RTP_HEADER
{
	union
	{
		unsigned short nFlag;
		struct						 
		{
			unsigned short m:1;	 
			unsigned short pt:7;
			unsigned short v:2;
			unsigned short p:1;
			unsigned short x:1;
			unsigned short cc:4;
		};
	};
	unsigned short nSeq;
	unsigned long  nTimeStamp;
	unsigned long  nSsrc;
}_RTP_HEADER;

#endif
/*
 * RTP data header
 */
typedef struct 
{
#if 0	//BIG_ENDIA
    unsigned int version:2;   /* protocol version */
    unsigned int p:1;         /* padding flag */
    unsigned int x:1;         /* header extension flag */
    unsigned int cc:4;        /* CSRC count */
    unsigned int m:1;         /* marker bit */
    unsigned int pt:7;        /* payload type */
	unsigned int seq:16;      /* sequence number */

#else
    unsigned int cc:4;        /* CSRC count */
    unsigned int x:1;         /* header extension flag */
    unsigned int p:1;         /* padding flag */
    unsigned int version:2;   /* protocol version */
 
	unsigned int pt:7;        /* payload type */
    unsigned int m:1;         /* marker bit */
	unsigned int seq:16;      /* sequence number */
#endif

    u_int32 ts;               /* timestamp */
    u_int32 ssrc;             /* synchronization source */
    u_int32 csrc[1];          /* optional CSRC list */
} rtp_hdr_t;

  


//////////////////////////////////////////////////////////////////////////
 
#endif